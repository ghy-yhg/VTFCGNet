cd /workspace/VTQA-Demo/
python /workspace/VTQA-Demo/test.py --MODEL_PATH './results/ckpts/ckpt_demo/epoch13.pkl' --FEATURE_TYPE 'region' --LANG 'zh'